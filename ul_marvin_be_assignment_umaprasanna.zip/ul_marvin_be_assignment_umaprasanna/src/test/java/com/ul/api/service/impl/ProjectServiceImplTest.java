package com.ul.api.service.impl;

import java.util.List;
import java.util.Optional;

import com.ul.api.domain.Project;
import com.ul.api.domain.request.CreateProjectRequest;
import com.ul.api.exception.ConflictParamException;
import com.ul.api.exception.InvalidRequestException;
import com.ul.api.exception.ProjectNotFoundException;
import com.ul.api.repository.ProjectRepository;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.assertj.core.api.Assertions.assertThat;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class ProjectServiceImplTest {

    @InjectMocks
    private ProjectServiceImpl projectService;

    @Mock
    private ProjectRepository projectRepository;


    @Test
    void createNewProject() {
        final var createProjectRequest = CreateProjectRequest.builder().name("New Project").status(Project.StatusEnum.IN_PROGRESS.name()).build();
        final var createdProject = Project.builder().name(createProjectRequest.getName()).status(createProjectRequest.getStatus()).build();
        when(projectRepository.existsByProjectName(createProjectRequest.getName())).thenReturn(false);
        when(projectRepository.saveAndFlush(any(Project.class))).thenReturn(createdProject);
        final var response = projectService.createNewProject(createProjectRequest);
        verify(projectRepository).existsByProjectName(createProjectRequest.getName());
        verify(projectRepository).saveAndFlush(any(Project.class));
        assertThat(response.getStatus().name()).isEqualTo(createProjectRequest.getStatus());
        assertFalse(response.isArchived());
    }

    @Test
    void createNewProjectWithAnExistingName() {
        final var createProjectRequest = CreateProjectRequest.builder().name("New Project").status(Project.StatusEnum.IN_PROGRESS.name()).build();
        when(projectRepository.existsByProjectName(createProjectRequest.getName())).thenReturn(true);
        assertThatThrownBy(() -> projectService.createNewProject(createProjectRequest))
                .isInstanceOf(ConflictParamException.class);
    }

    @Test
    void createNewProjectWithoutRequest() {
        assertThatThrownBy(() -> projectService.createNewProject(null))
                .isInstanceOf(InvalidRequestException.class);
    }

    @Test
    void createNewProjectWithoutName() {
        CreateProjectRequest createProjectRequest = CreateProjectRequest.builder().status(Project.StatusEnum.FINISHED.name()).build();
        assertThatThrownBy(() -> projectService.createNewProject(createProjectRequest))
                .isInstanceOf(InvalidRequestException.class);
    }

    @Test
    void createNewProjectWithoutStatus() {
        final var createProjectRequest = CreateProjectRequest.builder().name("NEW").build();
        assertThatThrownBy(() -> projectService.createNewProject(createProjectRequest))
                .isInstanceOf(InvalidRequestException.class);
    }

    @Test
    void getNotArchivedProjects() {
        when(projectRepository.findAllByArchivedFalse()).thenReturn(getProjectList());
        List<Project> responseList = projectService.getNotArchivedProjects();
        verify(projectRepository).findAllByArchivedFalse();
        assertThat(responseList).hasSize(3).extracting(Project::isArchived).contains(Boolean.valueOf("false"));
    }

    @Test
    void archiveAnProject() {
        final var existingProject = Project.builder().name("Existing Project").status(Project.StatusEnum.IN_PROGRESS.name()).build();
        when(projectRepository.findById(anyLong())).thenReturn(Optional.of(existingProject));
        when(projectRepository.saveAndFlush(any(Project.class))).thenReturn(existingProject.archive());
        Project archivedProject = projectService.archiveAnProject(1L);
        verify(projectRepository).findById(anyLong());
        verify(projectRepository).saveAndFlush(any(Project.class));
        assertTrue(archivedProject.isArchived());
    }

    @Test
    void archiveAnNotExistingProject() {
        final var projectId = 1L;
        when(projectRepository.findById(projectId)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> projectService.archiveAnProject(projectId))
                .isInstanceOf(ProjectNotFoundException.class);
    }

    private List<Project> getProjectList() {
        final var projectOne = Project.builder().name("First Project").status(Project.StatusEnum.IN_PROGRESS.name()).build();
        final var projectTwo = Project.builder().name("Second Project").status(Project.StatusEnum.IN_PROGRESS.name()).build();
        final var projectThree = Project.builder().name("Third Project").status(Project.StatusEnum.FINISHED.name()).build();
        return List.of(projectOne, projectTwo, projectThree);
    }

}
