package com.ul.api.web;

import com.ul.api.IntegrationTest;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;

import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class ProjectControllerTest extends IntegrationTest {

    private static final String BASE_PATH = "/projects";
    private static final String ARCHIVE_PROJECT_PATH = BASE_PATH + "/{id}";

    @Test
    void retrieveProjects() throws Exception {
        mvc.perform((get(BASE_PATH)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[*].name", hasItems("Project One", "Project Three")));
    }

    @Test
    void createProject() throws Exception {
        mvc.perform((post(BASE_PATH)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"my project\",\"status\":\"FINISHED\"}")))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.name", is("my project")))
                .andExpect(jsonPath("$.archived", is(false)));
    }

    @Test
    void createProjectWithInvalid() throws Exception {
        mvc.perform((post(BASE_PATH)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"my project\",\"status\":\"NEW\"}")))
                .andExpect(status().isNotAcceptable());
    }

    @Test
    void createProjectWithoutBody() throws Exception {
        mvc.perform(
                post(BASE_PATH)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    void createProjectWithoutName() throws Exception {
        mvc.perform(
                post(BASE_PATH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"status\":\"IN_PROGRESS\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void createProjectWithoutStatus() throws Exception {
        mvc.perform(
                post(BASE_PATH)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"MY PROJECT\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void archiveProject() throws Exception {
        mvc.perform((put(ARCHIVE_PROJECT_PATH, 1)
                .contentType(MediaType.APPLICATION_JSON)))
                .andExpect(status().isAccepted())
                .andExpect(jsonPath("$.name", is("Project One")))
                .andExpect(jsonPath("$.archived", is(true)));
    }

    @Test
    void archiveNonExistingProject() throws Exception {
        mvc.perform((put(ARCHIVE_PROJECT_PATH, 6)
                .contentType(MediaType.APPLICATION_JSON)))
                .andExpect(status().isNotFound());
    }
}
