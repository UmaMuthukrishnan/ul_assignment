package com.ul.api.exception;

import com.ul.api.domain.ApiError;
import org.springframework.web.bind.annotation.ResponseStatus;

import static org.springframework.http.HttpStatus.CONFLICT;
/**
 * ConflictParamException
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@ResponseStatus(CONFLICT)
public class ConflictParamException extends GenericException {

    private static final long serialVersionUID = 365090587265256049L;

    public ConflictParamException(ApiError apiError) {
        super(apiError);
    }
}
