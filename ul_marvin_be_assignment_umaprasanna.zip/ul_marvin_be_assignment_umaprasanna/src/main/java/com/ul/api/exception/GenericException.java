package com.ul.api.exception;


import com.ul.api.domain.ApiError;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * GenericException Handler for the API
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Getter
@NoArgsConstructor
public class GenericException extends RuntimeException {

    private ApiError apiError;

    public GenericException(String description) {
        super(description);
    }

    public GenericException(String description, Exception cause) {
        super(description, cause);
    }

    public GenericException(ApiError apiError) {
        this.apiError = apiError;

    }

}
