package com.ul.api.domain.request;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import static org.apache.logging.log4j.util.Strings.trimToNull;

/**
 * CreateProjectRequest class
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */

@Getter
@ToString
public final class CreateProjectRequest {

    private final String name;
    private final String status;

    @Builder
    private CreateProjectRequest(final String name, final String status) {
        this.name = trimToNull(name);
        this.status = trimToNull(status);
    }

}
