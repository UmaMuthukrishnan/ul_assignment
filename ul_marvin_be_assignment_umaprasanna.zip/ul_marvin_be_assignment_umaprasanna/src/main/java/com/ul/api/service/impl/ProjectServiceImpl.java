package com.ul.api.service.impl;

import java.util.List;

import javax.validation.Valid;

import com.ul.api.domain.ApiError;
import com.ul.api.domain.Project;
import com.ul.api.domain.request.CreateProjectRequest;
import com.ul.api.exception.ConflictParamException;
import com.ul.api.exception.InvalidRequestException;
import com.ul.api.exception.ProjectNotFoundException;
import com.ul.api.repository.ProjectRepository;
import com.ul.api.service.ProjectService;
import com.ul.api.utils.ErrorConstants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Implementation of ProjectService
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */

@Slf4j
@Service
@Transactional
@RequiredArgsConstructor
public class ProjectServiceImpl implements ProjectService {

    private final ProjectRepository projectRepository;

    /**
     * Retrieves all the non-archived Projects
     *
     * @return List of non-archived projects
     */
    @Override
    public List<Project> getNotArchivedProjects() {
        return projectRepository.findAllByArchivedFalse();
    }

    /**
     * Creates New project
     *
     * @param createProjectRequest Request with name and status of String types
     * @return created Project Object
     */

    @Override
    public Project createNewProject(@Valid final CreateProjectRequest createProjectRequest) {
        log.debug("Create Project with: createProjectRequest={}", createProjectRequest);

        if (createProjectRequest == null || createProjectRequest.getName() == null
                || (createProjectRequest.getStatus() == null)) {
            throw new InvalidRequestException
                    (new ApiError(ErrorConstants.INVALID_PROJECT_REQUEST_ERROR_CODE, "Invalid Project request : " + createProjectRequest,
                            HttpStatus.BAD_REQUEST));
        }

        if (projectRepository.existsByProjectName(createProjectRequest.getName())) {
            log.warn("There was an attempt to create a project that already exists. createProjectRequest={}", createProjectRequest);
            final var description = "Project already exists with the name : " + createProjectRequest.getName();
            throw new ConflictParamException
                    (new ApiError(ErrorConstants.EXISTING_PROJECT_ERROR_CODE, description,
                            HttpStatus.CONFLICT));
        }

        final var createdProject = Project.builder()
                .status(createProjectRequest.getStatus())
                .name(createProjectRequest.getName())
                .build();
        return projectRepository.saveAndFlush(createdProject);
    }

    /**
     * Archives given project
     *
     * @param projectId existing project
     * @return existing Project object tagged to the given id with "archived" param as "true"
     */

    @Override
    public Project archiveAnProject(final Long projectId) {
        final var description = "Project " + projectId + " not found ";
        final var existingProject = projectRepository.findById(projectId)
                .orElseThrow(() -> new ProjectNotFoundException(new ApiError(ErrorConstants.NON_EXISTING_PROJECT_ERROR_CODE, description,
                        HttpStatus.NOT_FOUND)));
        return projectRepository.saveAndFlush(existingProject.archive());
    }
}
