package com.ul.api.exception;



import com.ul.api.domain.ApiError;
import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;


/**
 * ProjectApiException for the API
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@ResponseStatus(value = HttpStatus.NOT_FOUND)
@Getter
public class ProjectApiException extends GenericException {

    public ProjectApiException(ApiError apiError) {
        super(apiError);
    }
}
