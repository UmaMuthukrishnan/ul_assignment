package com.ul.api.exception;


import java.time.Instant;
import java.util.Date;
import java.util.concurrent.ExecutionException;


import com.ul.api.domain.ApiError;
import com.ul.api.domain.ErrorDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * Exception Handler for Project API
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */

@ControllerAdvice
@Slf4j
public class ExceptionController extends ResponseEntityExceptionHandler {

    @ExceptionHandler(Throwable.class)
    public HttpEntity<ErrorDetails> handleGlobalException(Throwable t, WebRequest request) {
        ErrorDetails errorDetails = ErrorDetails.builder().timestamp(Date.from(Instant.now())).message(t.getMessage())
                .details(request.getDescription(false)).statusCode(HttpStatus.SERVICE_UNAVAILABLE.toString()).build();
        return new ResponseEntity<>(errorDetails, HttpStatus.SERVICE_UNAVAILABLE);
    }

    @ExceptionHandler(HttpServerErrorException.class)
    public HttpEntity<ErrorDetails> handleGlobalException(HttpServerErrorException ex, WebRequest request) {
        ErrorDetails errorDetails = ErrorDetails.builder().timestamp(Date.from(Instant.now())).message(ex.getMessage())
                .details(request.getDescription(false)).statusCode(ex.getStatusCode().toString()).build();
        return new ResponseEntity<>(errorDetails, ex.getStatusCode());
    }

    @ExceptionHandler({InvalidRequestException.class, ConflictParamException.class, ProjectNotFoundException.class, ProjectApiException.class})
    public final HttpEntity<ApiError> handleInvalidRequest(GenericException ex,
                                                           WebRequest request) {
        ApiError errorDetails = ApiError.builder().timestamp(Date.from(Instant.now()))
                .errorCode(ex.getApiError().getErrorCode())
                .description(ex.getApiError().getDescription())
                .requestURI(request.getDescription(false))
                .httpStatus(ex.getApiError().getHttpStatus())
                .build();
        return new ResponseEntity<>(errorDetails, ex.getApiError().getHttpStatus());
    }

    @ExceptionHandler({ExecutionException.class, InterruptedException.class})
    public final ResponseEntity<ErrorDetails> handleInternalServerError(ExecutionException ex, WebRequest request) {
        ErrorDetails errorDetails = ErrorDetails.builder().timestamp(Date.from(Instant.now())).message(ex.getMessage())
                .details(request.getDescription(false)).statusCode(HttpStatus.INTERNAL_SERVER_ERROR.toString()).build();

        return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler({IllegalArgumentException.class})
    public final ResponseEntity<ErrorDetails> handleIllegalArgumentException(IllegalArgumentException ex, WebRequest request) {
        ErrorDetails errorDetails = ErrorDetails.builder().timestamp(Date.from(Instant.now())).message(ex.getMessage())
                .details(request.getDescription(false)).statusCode(HttpStatus.NOT_ACCEPTABLE.toString()).build();

        return new ResponseEntity<>(errorDetails, HttpStatus.NOT_ACCEPTABLE);
    }


}
