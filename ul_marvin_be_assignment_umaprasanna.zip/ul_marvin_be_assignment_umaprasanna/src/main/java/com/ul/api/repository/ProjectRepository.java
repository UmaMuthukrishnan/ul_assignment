package com.ul.api.repository;

import java.util.List;

import com.ul.api.domain.Project;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * Repository for Project
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@Repository
public interface ProjectRepository extends JpaRepository<Project, Long> {

    @Query("SELECT (COUNT(p) > 0) FROM Project p WHERE (p.name = ?1)")
    boolean existsByProjectName(String name);

    List<Project> findAllByArchivedFalse();
}
