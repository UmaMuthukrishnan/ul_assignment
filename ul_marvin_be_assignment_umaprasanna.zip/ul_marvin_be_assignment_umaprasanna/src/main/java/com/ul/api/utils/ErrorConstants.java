package com.ul.api.utils;

/**
 * ErrorConstants - Class to store ERROR constants
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
public interface ErrorConstants {
    String INVALID_PROJECT_REQUEST_ERROR_CODE = "PROJECT_API-ERROR-001";
    String NON_EXISTING_PROJECT_ERROR_CODE = "PROJECT_API-ERROR-002";
    String EXISTING_PROJECT_ERROR_CODE = "PROJECT_API-ERROR-003";
}
