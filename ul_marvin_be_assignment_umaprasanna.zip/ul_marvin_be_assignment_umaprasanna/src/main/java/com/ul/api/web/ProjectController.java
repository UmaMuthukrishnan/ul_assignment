package com.ul.api.web;

import java.util.List;

import com.ul.api.domain.Project;
import com.ul.api.domain.request.CreateProjectRequest;
import com.ul.api.service.ProjectService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * Rest Controller class for accessing project endpoints
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */

@Slf4j
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/projects")
@RequiredArgsConstructor
public class ProjectController {

    private final ProjectService projectService;

    /**
     * Retrieves all the non-archived Projects
     *
     * @return List of non-archived projects
     */

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Retrieves all the non-archived Projects")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Retrieves project list")
    })
    @ResponseStatus(HttpStatus.OK)
    public List<Project> retrieveNotArchivedProjects() {
        return projectService.getNotArchivedProjects();
    }

    /**
     * Creates New project
     *
     * @param createProjectRequest Request with name and status of String types
     * @return created Project Object
     */

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Creates New project")
    @ApiResponses({
            @ApiResponse(code = 201, message = "Project created"),
            @ApiResponse(code = 400, message = "Invalid create request parameters"),
            @ApiResponse(code = 409, message = "Given project name already exists")
    })
    @ResponseStatus(HttpStatus.CREATED)
    public Project createNewProject(@Valid @RequestBody final CreateProjectRequest createProjectRequest) {
        return projectService.createNewProject(createProjectRequest);
    }

    /**
     * Archives given project
     *
     * @param id existing project
     * @return existing Project object tagged to the given id with "archived" param as "true"
     */
    @PutMapping(path = "{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Archives given project")
    @ApiResponses({
            @ApiResponse(code = 202, message = "Project archived"),
            @ApiResponse(code = 404, message = "Given project not found")
    })
    @ResponseStatus(HttpStatus.ACCEPTED)
    public Project archiveAnProject(@PathVariable final Long id) {
        return projectService.archiveAnProject(id);
    }

}
