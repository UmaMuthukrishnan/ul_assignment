package com.ul.api.exception;

import com.ul.api.domain.ApiError;
import org.springframework.web.bind.annotation.ResponseStatus;

import static org.springframework.http.HttpStatus.NOT_FOUND;

@ResponseStatus(NOT_FOUND)
public class ProjectNotFoundException extends GenericException {

    private static final long serialVersionUID = 365090587265256049L;

    public ProjectNotFoundException(ApiError apiError) {
        super(apiError);
    }
}
