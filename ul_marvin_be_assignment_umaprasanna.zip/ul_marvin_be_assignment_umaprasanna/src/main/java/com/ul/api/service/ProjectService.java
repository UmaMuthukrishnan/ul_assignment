package com.ul.api.service;

import java.util.List;

import com.ul.api.domain.Project;
import com.ul.api.domain.request.CreateProjectRequest;
/**
 * ProjectService
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
public interface ProjectService {

    List<Project> getNotArchivedProjects();

    Project createNewProject(CreateProjectRequest projectCreateRequest);

    Project archiveAnProject(Long projectId);

}
