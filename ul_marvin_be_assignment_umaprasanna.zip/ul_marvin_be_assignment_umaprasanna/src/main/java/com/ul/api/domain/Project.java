package com.ul.api.domain;




import java.time.LocalDateTime;


import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import static lombok.AccessLevel.PROTECTED;

/**
 * Project -Entity class
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */

@Entity
@Getter
@NoArgsConstructor(access = PROTECTED)
@ToString
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotNull(message = "Start Date should not be null")
    private String name;
    @Enumerated(EnumType.STRING)
    private StatusEnum status;
    private LocalDateTime dateCreated;
    private boolean archived;

    @Builder
    private Project( final String name, final String status) {
        this.name = name;
        this.status = StatusEnum.valueOf(status);
        this.archived=false;
        this.dateCreated = LocalDateTime.now();
    }

    public Project archive()
    {
        this.archived=true;
        return this;
    }

    public enum StatusEnum {
        IN_PROGRESS,
        FINISHED
    }


}
