package com.ul.api.exception;


import com.ul.api.domain.ApiError;
import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;


/**
 * InvalidRequestException  for the API
 *
 * @author Umaprasanna Muthukrishnan
 * @version 1.0
 */
@ResponseStatus(value = HttpStatus.BAD_REQUEST)
@Getter
public class InvalidRequestException extends GenericException {

    public InvalidRequestException(ApiError apiError) {
        super(apiError);
    }
}
