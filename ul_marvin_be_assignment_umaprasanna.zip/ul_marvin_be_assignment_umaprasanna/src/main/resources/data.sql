insert into project (id, name, date_created,status,archived) values
(1, 'Project One', '2021-01-1 15:10:56.768763','IN_PROGRESS','FALSE'),
(2, 'Project Two', '2021-01-1 15:10:56.768763','FINISHED','TRUE'),
(3, 'Project Three', '2021-01-1 15:10:56.768763','IN_PROGRESS','FALSE');